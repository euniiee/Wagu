package com.wagu.dto;

public class MemberDTO {
	private int memberID;
	private String email;
	private String pw;
	private String name;
	private String birth;
	private int phone;
	private String image;
	
	public MemberDTO(int memberID, String email, String pw, String name, String birth, int phone, String image) {
		this.memberID = memberID;
		this.email = email;
		this.pw = pw;
		this.name = name;
		this.birth = birth;
		this.phone = phone;
		this.image = image;
	}
	
	public int getMemberID() {
		return memberID;
	}
	public void setMemberID(int memberID) {
		this.memberID = memberID;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPw() {
		return pw;
	}
	public void setPw(String pw) {
		this.pw = pw;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBirth() {
		return birth;
	}
	public void setBirth(String birth) {
		this.birth = birth;
	}
	public int getPhone() {
		return phone;
	}
	public void setPhone(int phone) {
		this.phone = phone;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
}
