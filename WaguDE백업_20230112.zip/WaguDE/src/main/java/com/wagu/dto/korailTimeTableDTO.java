package com.wagu.dto;

public class korailTimeTableDTO {
	private String trainType;
	private int trainNum;
	private String startTime;
	private String arriveTime;
	private int sumPrice;
	
	public korailTimeTableDTO(String trainType, int trainNum,
			String startTime, String arriveTime, int sumPrice) {
		super();
		this.trainType = trainType;
		this.trainNum = trainNum;
		this.startTime = startTime;
		this.arriveTime = arriveTime;
		this.sumPrice = sumPrice;
	}

	
	public String getTrainType() {
		return trainType;
	}

	public void setTrainType(String trainType) {
		this.trainType = trainType;
	}

	public int getTrainNum() {
		return trainNum;
	}

	public void setTrainNum(int trainNum) {
		this.trainNum = trainNum;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getArriveTime() {
		return arriveTime;
	}

	public void setArriveTime(String arriveTime) {
		this.arriveTime = arriveTime;
	}

	public int getSumPrice() {
		return sumPrice;
	}

	public void setSumPrice(int sumPrice) {
		this.sumPrice = sumPrice;
	}
	
	
	
	
}
