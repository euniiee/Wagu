package com.wagu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.wagu.connection.DBconnection;

public class MemberDAO {
	public boolean loginCheck(String email, int pw) {
		Connection conn = DBconnection.getConnection();
		
		String sql = "SELECT count(*) FROM members WHERE email=? AND pw=?";
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, email);
			pstmt.setInt(2, pw);
			ResultSet rs = pstmt.executeQuery();
			
			int cnt = 0;
			if(rs.next()) {
				cnt = rs.getInt(1);	
			}
			rs.close();
			pstmt.close();
			conn.close();
			
			if(cnt == 1) {
				return true;
			}
			return false;
		} catch(Exception e) {	
			e.printStackTrace();
			return false;
		}
		
		
	
	
	}
}
