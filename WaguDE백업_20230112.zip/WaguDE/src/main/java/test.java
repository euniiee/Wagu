import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Scanner;

class ProfileVO {
	String email;
	String name;
	String image;
	
	
	public ProfileVO(String email, String name, String image) {
		super();
		this.email = email;
		this.name = name;
		this.image = image;
	}

	@Override
	public String toString() {
		return "Profile [email=" + email + ", name=" + name + ", image=" + image + "]";
	}
	
}
// timeTable테이블에서 예약 범위 정하기.
public class test {
	static ArrayList<ProfileVO> profilelist;
	static Connection conn;
	static Scanner sc = new Scanner(System.in);
	static void connect() throws Exception {
		String driver = "oracle.jdbc.driver.OracleDriver";
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String dbID = "wagu";
		String dbPW = "1234";
		
		Class.forName(driver);
		conn = DriverManager.getConnection(url, dbID, dbPW);
	}
//	static String email;
	// 이름 / 프로필사진  <------------ SELECT name, 프로필이미지 FROM members WHERE id =_____LoginID;
static void profile() throws Exception {
		profilelist = new ArrayList<ProfileVO>();
		
		String sql = "select name, image from members where email = ?";
		System.out.print("이메일 입력 : ");
		String email = "sdktj1@nacerm.com";
		
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, email);
		pstmt.executeUpdate();
		ResultSet rs = pstmt.executeQuery();
		
//		String name = null;
//		String image = null;
		if(rs.next()) {
			String name = rs.getString("name");
			String image = rs.getString("image");
			profilelist.add(new ProfileVO(email,name,image));
		}
		rs.close();
		pstmt.close();
		System.out.println(profilelist.get(0));
//	System.out.println(name + "/" + image);
//		return name + " /" + image;
//		return name;
	}
	
	static int[] findTimetableId(int trainNum, String strStartStation, String strTerminalStation, String strStartTime) throws Exception{
		
		int startTimetableId = 0; // timetable 테이블 -> 시작하는 timetable_id
		int endTimetableId = 0;
		
		//System.out.println("trainNum : " + trainNum);
		//System.out.println("strStartStation : " + strStartStation);
		//System.out.println("strStartTime : " + strStartTime);
		//SELECT timetable_id FROM timetable WHERE train_num=1314 AND start_station='천안' AND start_time='7:1'
		String sql = "SELECT timetable_id FROM timetable WHERE train_num=? AND start_station=? AND start_time=?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, trainNum);
		pstmt.setString(2, strStartStation);
		pstmt.setString(3, strStartTime);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			startTimetableId = rs.getInt(1);
		}
		rs.close();
		pstmt.close();
		
//		System.out.println("startID :" + startTimetableId);
		
		sql = "SELECT timetable_id FROM timetable WHERE train_num=? AND timetable_id>=? AND terminal_station=?";
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, trainNum);
		pstmt.setInt(2, startTimetableId);
		pstmt.setString(3, strTerminalStation);
		rs = pstmt.executeQuery();
		while(rs.next()) {
			endTimetableId = rs.getInt(1);
		}
		rs.close();
		pstmt.close();
//		System.out.println("endID :"  + endTimetableId);
		
		int[] timeTableId_Array = new int[endTimetableId-startTimetableId+1];
		for(int i=0; i<=endTimetableId-startTimetableId; i++) {
			timeTableId_Array[i] = startTimetableId+i; 
		}
		return timeTableId_Array;
		
	}
	public static void main(String[] args) throws Exception {
		connect();
		
		profile(); // 상단에 이름, 프로필 이미지 확인.
		
		System.out.println("코레일 예약 화면");
		
		System.out.print("열차번호(ex.1312):");
		int trainNum = sc.nextInt();
		System.out.print("출발역 :");
		String strStartStation = sc.next();
		System.out.print("도착역:");
		String strTerminalStation = sc.next();
		System.out.print("출발 시간(ex. 05:28) : ");
		String strStartTime = sc.next();
		
		int [] arrayResult = findTimetableId(trainNum, strStartStation, strTerminalStation, strStartTime);
		
		System.out.print("timetableId :");
		for(int n:arrayResult) {
			System.out.print(n + " ");
		}
		
		conn.close();
		
	}
}

