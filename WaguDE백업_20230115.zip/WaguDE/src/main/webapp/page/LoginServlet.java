import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wagu.dao.MemberDAO;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		
		MemberDAO mDao = new MemberDAO();
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String str ="";
		try {
			if(mDao.loginCheck(id, pw)) {
				//로그인 성공시.
			}else {
				str="실패";
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		RequestDistcher rd = request.getRequestDispatcher("LoginAction.jsp");
		request.setAttribute("login_result", str);
		rd.forward(request, response);
	}

}
