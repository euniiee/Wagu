$(function() {

  // 최근 검색 구간 닫기
  $('.close_icon').click(function(){
    $(this).parent().css('display','none');
  });

});