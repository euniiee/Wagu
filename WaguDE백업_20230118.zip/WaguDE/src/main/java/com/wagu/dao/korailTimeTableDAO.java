package com.wagu.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.TreeMap;

import com.wagu.connection.DBconnection;
import com.wagu.dto.korailTimeTableDTO;

public class korailTimeTableDAO {
	public ArrayList<korailTimeTableDTO> listTimetable(String startStation, String arriveStation, int adult, int child, String order){
		String strOrderBy = "";
		if(order==null || "출발시간순".equals(order)) {
			strOrderBy = "to_date(start_time, 'hh24:mi')";
		}else if("도착시간순".equals(order)) {
			strOrderBy = "to_date(arrive_time, 'hh24:mi')";
		}else if("소요시간순".equals(order)) {
			strOrderBy = "to_date(taken_time, 'hh24:mi')";
		}
		
		Connection conn = DBconnection.getConnection();
		
		ArrayList<korailTimeTableDTO> list = new ArrayList<korailTimeTableDTO>();
		
		String sql = "SELECT tp.train_num, train_type, start_station, terminal_station, start_time, arrive_time,\r\n"
				+ "	FLOOR(((to_date(arrive_time, 'hh24:mi')-to_date(start_time, 'hh24:mi'))*24*60)/60) || ':' || MOD(((to_date(arrive_time, 'hh24:mi')-to_date(start_time, 'hh24:mi'))*24*60),60) taken_time,"
				+ "	adultprice, childprice\r\n"
				+ "	FROM train_price tp, train_number tn\r\n"
				+ "	WHERE tn.train_num = tp.train_num AND start_station = ? AND terminal_station = ?"
				+ " ORDER BY " + strOrderBy;
		
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, startStation);
			pstmt.setString(2, arriveStation);
			ResultSet rs = pstmt.executeQuery();
			
			while(rs.next()) {
				String trainType = rs.getString("train_type");
				int trainNum = rs.getInt("train_num");
				String startTime = rs.getString("start_time"); // db에 있는 출발시간 ex) 8:0
				String arriveTime = rs.getString("arrive_time"); // db에 있는 도착시간 8:0
				
				// 소요시간 = 도착시간- 출발시간
				String timeTaken = "";
				SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
				
				//요청시간을 Date로 parsing 후 time 가져오기
				Date dateStartTime = sdf.parse(startTime);
				Date dateTerminalTime = sdf.parse(arriveTime);
				long startTime2 = dateStartTime.getTime();
				long arriveTime2 = dateTerminalTime.getTime();
				long difference = arriveTime2-startTime2; // 60000ms=60초=1분
//System.out.println("difference : " + difference);	 			
				if(difference<0) {
					difference += 24 * 60 * 60 * 1000;		
				}
				int minutes = (int)(difference/60000);
				int hours = 0;
				while(minutes>=60) {
					hours++;
					minutes-=60;	
				}
				timeTaken = hours + "시간" + minutes + "분";
				int adultPrice = rs.getInt("adultPrice");
				int childPrice = rs.getInt("childPrice");
				int sumPrice = adult*adultPrice + child*childPrice;
				list.add(new korailTimeTableDTO(trainType, trainNum, startTime,  arriveTime, timeTaken, sumPrice)); 
			}
			rs.close();
			pstmt.close();
			conn.close();
		} catch(Exception e) {
			e.printStackTrace();
			
		}
		return list;
	}
	
	public TreeMap<String,Boolean> getSeatsStatus() {
		
		return null;
	}
}
