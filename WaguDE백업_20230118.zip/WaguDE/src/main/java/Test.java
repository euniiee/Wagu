import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;

public class Test {
	public static void main(String[] args) {
		TreeMap<String,Boolean> mapSeats = new TreeMap<String,Boolean>();
		// KTX
		for(int i=1; i<=15; i++) {
			for(char j='A'; j<='D'; j++) {
//				if(i<=9)
//					mapSeats.put("0"+i+j, false);
//				else
					mapSeats.put(""+i+j, false);
			}
		}

		mapSeats.put("2A", true);
		mapSeats.put("2B", true);
		mapSeats.put("2C", true);
		
		System.out.println(mapSeats);
		
//		Set<String> keysets = mapSeats.keySet();
//		Iterator<String> itr = keysets.iterator();
//		while(itr.hasNext()) {
//			String key = itr.next();
//			Boolean value = mapSeats.get(key);
//			System.out.println(key + " : " + value);
//		}
		
		// map ---> JSONObject
		
	}
}
